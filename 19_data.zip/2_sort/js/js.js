import products from "https://woals5432.github.io/asan/db.json" assert{type: 'json'};
//assert{type:'json'} - 외부파일이 json이라고 확실히 명시

const btn = document.querySelector('button')
const ascebtn = document.querySelector('.ascending') //오름차순버튼
const descbtn = document.querySelector('.descending') //내림차순버튼



const createItem = (product) => {
  const ul = document.querySelector('.list'); //원래있는거 선택
  const li = document.createElement('li'); //새로운 엘리먼트 생성
  const img = document.createElement('img');
  const strong = document.createElement('strong');
  const p = document.createElement('p');
  const span = document.createElement('span');

  const price = new Intl.NumberFormat('ko-kr', {
    style: 'currency',     //통화단위
    currency: 'KRW'        //원화
  }).format(product.price) //포맷을 바꿀 데이터
  //Intl.NumberFormat - 각국에 맞는 숫자서식을 지원하는 객체 생성자(클라스)

  //li.setAttribute('id',product.id);
  li.id = product.id; //id는 안 만들어도 됨(기본 속성으로 있음)
  img.setAttribute('src', product.img); //img에 src속성 만들고 value내용삽입
  strong.classList.add('name')          //strong에 클라스 name 생성
  strong.innerText = product.name;
  p.classList.add('info');
  p.innerText = product.info;
  span.className = "price";
  span.innerText = price;  //위에서 한국돈 표시 방법으로 바꾼 것을 집어 넣어줌

  li.append(img, strong, p, span);

  ul.append(li);

  console.log(ul);
};

const importData = () => {
  products.data.forEach((product) => {
    if (!document.getElementById(product.id)) { //클릭할때마다 추가되는 것 방지(기존아이디값이 없을때만 작동)
      createItem(product)
    }
  })
}

//소트된 아이템들을 뿌려주기 위해 먼저 화면의 아이템들을 지우는 함수
const removeItems = () => {
  const items = document.querySelectorAll('li');
  items.forEach((aa)=>{
    aa.remove()
  })
}


//내림차순 정렬 함수
const sortDesc = () => {
  const myProduct = products.data.sort((a, b) => {
    return b.price - a.price
  });
  removeItems() //화면의 li들을 다 없애주는 함수 실행
  myProduct.forEach((product) => {
    createItem(product)
  })
}

//오름차순 정렬 함수
const sortAsce = () => {
  const myProduct = products.data.sort((a, b) => {
    return a.price - b.price
  });
  removeItems()
  myProduct.forEach((product) => {
    createItem(product)
  })
}


btn.addEventListener('click', importData)

ascebtn.addEventListener('click', sortAsce)   //오름차순 버튼 클릭후 함수 실행
descbtn.addEventListener('click', sortDesc)
