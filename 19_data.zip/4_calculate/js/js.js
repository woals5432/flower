

const btn = document.querySelector('button');

let myProduct, products;  //products.data
let selected = [] //체크된 아이템들을 저장할 배열

async function getJson(){
  const response = await fetch('https://woals5432.github.io/asan/db.json');
  products = await response.json()
  return products;
  
}
getJson()  
  //.then(products => importData(products)) //함수 실행해서 데이터를 불러온뒤 바로 importData함수 실행

const printTotal = (price)=>{
  const spanResult = document.querySelector('.total_price');
  const priceFormmatted = new Intl.NumberFormat('ko-kr', {
    style: 'currency',     //통화단위
    currency: 'KRW'        //원화
  }).format(price) 
  spanResult.innerText = priceFormmatted;
}

//계산해주는 함수 정의
const calculate =() => {
  const result= selected.reduce((sum,item)=>{
    return sum + item.price
  },0)
  printTotal(result)
  //console.log('총합계 result-',result);
}

  //체크박스 체크하면 실행될 함수 정의
  const addCart = (aa) => {
    //console.log('선택한 input의 부모li',aa.target.parentElement);  

    const { id } = aa.target.parentElement; //아이디(선택한 input의 부모 li)
    const { checked } = aa.target; //선택이 되었을때 (true/false)
    console.log('checked 여부 ', checked);

    if (checked == true) {  //체크되었을때 -> 배열에 추가
      myProduct.forEach(aa=>{
        if(aa.id === parseInt(id)){    
          //내가 선택한 input부모 아이디와 json 아이템 아이디와 같은것을 미리 만든 selected 배열에 집어 넣음 
          //parseInt(id) 문자열id를 정수로 전환/ 그냥 ==로 해줘도 됌
          selected.push(aa)
        }
      })
      console.log(selected);
    } else {  //체크가 해제되면 -> 배열에서 삭제
      selected = selected.filter((bb)=>{
        return bb.id !== parseInt(id);
        
      })
    }
    calculate(); //계산해주는 함수 호출

  }

const createItem = (product) => {
  const ul = document.querySelector('.list'); //원래있는거 선택

  const li = document.createElement('li'); //새로운 엘리먼트 생성
  const check = document.createElement('input');
  const img = document.createElement('img');
  const strong = document.createElement('strong');
  const span = document.createElement('span');

  const price = new Intl.NumberFormat('ko-kr', {
    style: 'currency',     //통화단위
    currency: 'KRW'        //원화
  }).format(product.price) //포맷을 바꿀 데이터
  //Intl.NumberFormat - 각국에 맞는 숫자서식을 지원하는 객체 생성자(클라스)

  //li.setAttribute('id',product.id);
  li.id = product.id; //id는 안 만들어도 됨(기본 속성으로 있음)
  img.setAttribute('src', product.img); //img에 src속성 만들고 value내용삽입
  strong.classList.add('name')          //strong에 클라스 name 생성
  strong.innerText = product.name;
  span.className = "price";
  span.innerText = price;  //위에서 한국돈 표시 방법으로 바꾼 것을 집어 넣어줌



  //check(input)
  check.setAttribute('type', 'checkbox');
  check.addEventListener('change', addCart) //체크가 될때 addCart 함수 실행



  li.append(check, img, strong, span);

  ul.append(li);

};

//creatItem 함수 끝
const importData = () => {
  myProduct = products.data
  myProduct.forEach((product) => {
    if (!document.getElementById(product.id)) { //클릭할때마다 추가되는 것 방지(기존아이디값이 없을때만 작동)
      createItem(product)
    }

  })
}

btn.addEventListener('click', importData)

